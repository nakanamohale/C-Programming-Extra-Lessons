
struct point2D{
	double x;
	double y;
};

//TODO: create below a C++ struct to store 3D euclidean points
struct point3D{
	double x;
	double y;
	double z;
};
// I think this should be a BONUS quesion
//TODO: create below a C++ class with the following charactersitics:
//   attributes to store an n-Dimensional euclidean points
// 	2 methods: 1.) generatePoints, to generate n-Dimensional points of length N
//			   2.) MaxDistance, to compute the maximum distance between pairs of points;


